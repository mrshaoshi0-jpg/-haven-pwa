# Haven PWA（iPhone 版）

這是 Haven 的免 Mac 原型版：可在 iPhone Safari 使用，並可加入主畫面。它不是 App Store 原生 App。

## 功能
- 黑色極簡介面、簡單轉場動畫
- 設定密碼／解鎖／手動鎖定
- 匯入照片與影片、縮圖瀏覽、播放影片、刪除項目
- 使用 Web Crypto 的 PBKDF2 + AES-GCM 在瀏覽器端加密媒體內容
- 媒體資料存放在此網站的 IndexedDB；程式沒有把媒體傳送到伺服器
- Service Worker 快取靜態介面，初次開啟並完成快取後可嘗試離線使用

## 非常重要的限制
1. 這是原型，不是經過安全審查的保險庫。請勿存放極度敏感的內容。
2. 忘記密碼就無法解密已匯入的媒體；沒有密碼重設或備份功能。
3. 清除 Safari 網站資料、瀏覽器回收儲存空間、裝置故障，都可能令資料永久遺失。請保留原始檔案的安全備份。
4. iPhone 可能不適合一次匯入非常大的影片；若失敗，請先試較小檔案。
5. 加入主畫面不是安裝原生 App。初次部署需要網路與 HTTPS 網站；媒體本身不會上傳，但網站原始碼會公開。
6. iOS 可能在切到背景時鎖定介面。此版本會在頁面進入背景時自動鎖定。
7. 媒體的加密檔案與部分必要中繼資料留在瀏覽器本機；網站網址本身不是秘密。

## 用 iPhone 部署（GitHub Pages 免費靜態網站）
需要 GitHub 帳號。GitHub Pages 免費方案通常要求公開 repository，因此網站程式碼會公開；不要把照片或影片放進 repository。

1. 在 Safari 開啟 https://github.com/new，登入並建立 repository，例如 `haven-pwa`，選 **Public**。
2. 解壓縮 `Haven_PWA.zip`（在「檔案」App 的下載項目中點 ZIP）。
3. 在 repository 頁面選 **Add file → Upload files**，選取解壓後的 `index.html`、`manifest.json`、`sw.js`、`icon.svg`。不要上傳 ZIP，也不要上傳私人媒體。
4. 按 **Commit changes**。
5. 開啟 repository 的 **Settings → Pages**，在 Build and deployment 中選 **Deploy from a branch**，Branch 選 `main`、資料夾選 `/(root)`，按 **Save**。
6. 等待 Pages 發佈，回到 Settings → Pages，打開顯示的網站網址。網址通常是 `https://你的帳號.github.io/haven-pwa/`。
7. 用 Safari 開啟該 HTTPS 網址，保持網頁開啟片刻讓快取完成；然後按分享按鈕 → **加入主畫面** → **加入**。
8. 從主畫面開啟 Haven，第一次設定密碼。先用一張不重要的測試照片試匯入、鎖定、重新解鎖及離線開啟，再考慮匯入其他媒體。

官方說明：
- GitHub Pages：https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- iPhone 加入主畫面：https://support.apple.com/guide/iphone/open-as-web-app-iphea86e5236/ios

## 更新
更新程式碼後，重新載入網站。若仍顯示舊版本，可先關閉 Haven，再於 Safari 重新開啟網站並等待快取更新。

## 技術
純 HTML/CSS/JavaScript，無第三方套件，無追蹤程式，無外部 API 呼叫。
